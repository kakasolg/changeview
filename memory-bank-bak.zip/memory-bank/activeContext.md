# Active Context - 현재 작업 상황

## 🎯 현재 진행 중인 작업

### 단계: 🎲 8면체 주사위 64괘 선택 시스템 개발 시작! - 혁신적 UX 개선 계획
**목표**: 기존 텍스트 입력 방식에서 → 직관적 주사위 인터랙션으로 진화, 주역 원리에 부합하는 능동적 괘 선택 시스템 구축

## 🎲 새로운 계획: 8면체 주사위 64괘 선택 시스템

### 현재 시스템의 제약 및 개선 이유
**기존 방식**: 사용자 텍스트 입력 → AI가 괘 선택 → 결과 제시
- **문제점**: 점술적 느낌, 사용자 수동성, 주역 원리와 거리감
- **개선 방향**: 사용자가 직접 괘를 선택하는 능동적 참여 방식

### 8면체 주사위 시스템 설계
**수학적 완벽성**: 8 × 8 = 64 (주역 64괘와 정확히 일치)
- **첫 번째 주사위**: 상괘(上卦) - 8가지 기본 상징
- **두 번째 주사위**: 하괘(下卦) - 8가지 기본 상징
- **조합**: 상괘 + 하괘 = 64가지 고유한 괘 조합

### UX 혁신 및 철학적 정합성
- **직관적 인터랙션**: 3D 주사위 애니메이션 + 사용자 클릭으로 정지
- **주역 원리 부합**: 우연의 필연성, 동기감응(동시간 마음의 공명)
- **능동적 참여**: 사용자가 직접 '운명'을 선택하는 주체적 경험

### AI 활용의 진화
**기존**: AI가 괘 선택 → 점술적 느낌
**개선**: 사용자가 괘 선택 → AI가 해석과 적용에 집중 → 더 과학적

### 구현 계획 및 현재 진행상황
**✅ 1단계: 3D 주사위 애니메이션 프로토타입 제작 (95% 완료)**
- ✅ 8면체 주사위 3D 모델링 (Three.js 기반)
- ✅ 파란색(상괘)/빨간색(하괘) 주사위 2개 구현
- ✅ 실시간 회전 애니메이션 구현
- ✅ 사용자 클릭 인터랙션 (굴리기/정지하기)
- ✅ 64괘 계산 로직 완성: (상괘-1) × 8 + 하괘
- ✅ 팔괘 상징 표시 시스템 (☰☱☲☳☴☵☶☷)
- ✅ 테스트 페이지 완성: `/dice-test`
- ⚠️ 팔괘 상징을 주사위 면에 직접 표시 (기술적 이슈로 보류)

**🔄 2단계: 기존 시스템과 통합 (대기 중)**
- MongoDB 64괘 데이터와 연동
- Google Gemini API 해석 엔진 연결
- 찰리 멍거 정신 모델 시스템 통합

**⏳ 3단계: 완성 및 배포**
- 사용자 테스트 및 피드백 반영
- 최종 배포

## 🧪 다음 테스트 계획 및 개선 방안

### 우선순위 1: 팔괘 상징 주사위 면 표시 완성
**문제**: 다중 재료 배열이 Three.js 8면체와 호환성 문제
**해결 방안들**:
1. **커스텀 8면체 제작**: 8개 평면을 조합해 각각 다른 텍스처 적용
2. **3D 스프라이트 오버레이**: 주사위 표면에 팔괘를 별도 스프라이트로 배치
3. **단일 텍스처 UV 매핑**: 하나의 텍스처에 8개 상징을 배치, UV로 분할
4. **3D 텍스트 생성**: TextGeometry로 상징을 3D로 만들어 각 면에 부착

### 우선순위 2: 기존 시스템과 연동
**목표**: 주사위 결과를 실제 64괘 해석으로 연결
**테스트 항목들**:
- `/api/hexagrams?number={결과}` API 호출 테스트
- MongoDB에서 해당 괘 데이터 조회 확인
- Google Gemini API로 상황별 해석 생성
- 찰리 멍거 정신 모델 포함 여부 검증

### 우선순위 3: UX/UI 향상
**개선 방안들**:
- **물리 엔진 추가**: 더 현실적인 주사위 굴림 시뮬레이션
- **사운드 효과**: 주사위 굴리는 소리, 정지음
- **파티클 효과**: 주사위 굴릴 때 반짝임 효과
- **카메라 각도**: 더 나은 시점에서 주사위 관찰
- **반응형 최적화**: 모바일/태블릿 터치 지원

### 우선순위 4: 성능 및 안정성
**테스트 항목들**:
- 메모리 누수 방지 (Three.js 객체 정리)
- 브라우저 호환성 (Chrome, Firefox, Safari, Edge)
- 모바일 성능 테스트
- 로딩 속도 최적화

### 우선순위 5: 고급 기능
**미래 개선 방안들**:
- **다양한 주사위 디자인**: 유저가 선택할 수 있는 스킨
- **애니메이션 커스터마이징**: 회전 속도, 정지 시간 조절
- **히스토리 기능**: 이전 결과들 저장/표시
- **통계 분석**: 사용자별 괘 패턴 분석
- **소셜 공유**: 결과를 SNS에 공유

### 즉시 테스트 가능한 항목들
1. **팔괘 표시 방법 2-3가지 프로토타입 제작**
2. **`/api/hexagrams/{number}` 호출하여 실제 괘 데이터 가져오기**
3. **주사위 결과와 MongoDB 데이터 연동 테스트**
4. **모바일 브라우저에서 터치 인터랙션 테스트**
5. **다양한 브라우저에서 3D 렌더링 호환성 확인**


**✅ 64괘 정신 모델 대폭 개선 완료 - 찰리 멍거 격자틀 이론 완전 적용**
- **배경 철학**: 찰리 멍거의 격자틀 이론(Latticework of Mental Models) 기반
- **점술감 완전 제거**: 과학적/학문적 정신 모델로만 구성, 심리학/경제학/물리학 바탕
- **주요 개선 성과**: 
  - 표기법 100% 통일: 모든 모델을 '한글명 (영문명)' 형태로 표준화
  - 중복 완전 제거: 네트워크 효과(4→1), 안전마진(3→1), 복리(4→1) 등
  - 멍거 철학 강화: 던닝-크루거 효과, 사전부검, 역발상 사고 등 핵심 모델 추가
  - 실무 적용성 극대화: 투자/경영 현장에서 바로 쓸 수 있는 실용적 모델들
- **MongoDB 전체 64괘 일괄 업데이트 완료**: 새로운 정신 모델 체계 적용
- **Git 커밋 완료**: 변경사항 안전하게 저장

**✅ Function Implementation MongoDB 연결 및 정신 모델 포함 완전 수정**
- **MongoDB API 연결 수정**: 단일 객체 처리 로직 수정으로 정상 연결 확인
- **정신 모델 Function Calling 포함**: 모든 Function 결과에 찰리 멍거 정신 모델 포함
- **Fallback 데이터 개선**: MongoDB 실패시에도 정신 모델 포함하여 일관성 유지
- **테스트 결과 검증**: Gemini가 "관련 개념 (정신 모델): '활성화 에너지(Activation Energy)'" 완벽 인용 ✅
- **과학적 설명 구현**: "어떤 일이 시작되고 진행되기 위해 필요한 최초의 에너지" 물리학 기반 설명
- **점술감 완전 제거**: 찰리 멍거 격자틀 이론 기반 과학적/학문적 접근법 구현 성공 ✅
- **신뢰성 확보**: 투자/경영 현장에서 활용 가능한 실무적 정신 모델 시스템 완성
- **Git 커밋 완료**: Function-Implementation-Mental-Models-Success


**✅ Tailwind CSS 렌더링 문제 완전 해결**
- **문제 원인**: `tailwind.config.js`의 빈 `content: []` 배열로 인한 파일 스캔 실패
- **해결 방법**: 
  - 문제 파일 `tailwind.config.js` 삭제
  - `src/app/globals.css` 생성 및 Tailwind directives 추가
  - `layout.tsx`에 globals.css import 추가
  - 종합 테스트 페이지 `/test` 생성
- **검증 완료**: 메인 페이지와 테스트 페이지 모두 정상 렌더링 확인 ✅
  - 메인 페이지: `http://localhost:3000` - 완전 정상 작동
  - 테스트 페이지: `http://localhost:3000/test` - 모든 Tailwind 기능 검증 완료

## ✅ 완료된 작업 (2025-06-11 업데이트)

### 프로젝트 기반 구축 (100% 완료)
- ✅ **Next.js 15.3.3 프로젝트 생성** - TypeScript + Tailwind + App Router 완료
- ✅ **Google Gemini API 연동 완료** - @google/genai 라이브러리 사용
- ✅ **gemini-2.5-flash-preview-05-20 모델 설정** - 최신 권장 모델 적용
- ✅ **환경 변수 설정 완료** - GOOGLE_API_KEY, GEMINI_MODEL, MONGODB_URI 설정
- ✅ **Memory Bank 복사 및 업데이트** - 프로젝트 문서화 완료

### MongoDB 데이터베이스 시스템 (100% 완료) 🎯
- ✅ **MongoDB 연결 라이브러리** - `src/lib/database.js` 완성
- ✅ **Mongoose 스키마 정의** - `src/models/Hexagram.js` 완성
- ✅ **MongoDB 연결 테스트** - localhost:27017 정상 연결 확인
- ✅ **데이터베이스 생성** - wisdom_lenses DB 생성 완료

### 64괘 API 시스템 (100% 완료) 🚀
- ✅ **CRUD API 구현** - `/api/hexagrams` 완전 구현
- ✅ **GET 기능**: 전체 조회, 번호별 조회, 키워드 검색, 페이지네이션
- ✅ **POST 기능**: 시드 데이터 입력, 단일 괘 생성
- ✅ **DELETE 기능**: 전체 삭제, 특정 괘 삭제
- ✅ **검색 시스템**: 키워드 기반 검색 및 복합 인덱스
- ✅ **에러 처리**: 완전한 에러 핸들링 및 응답 표준화

### 실제 동작 검증 (100% 성공) ✅
- ✅ **MongoDB 연결 테스트** - `/api/test-db` 정상 동작
- ✅ **테스트 데이터 입력** - 5개 괘 정상 입력 및 조회
- ✅ **Playwright 자동 테스트** - 모든 API 엔드포인트 정상 동작
- ✅ **키워드 검색 테스트** - "창조" 검색 정상 작동
- ✅ **번호별 조회 테스트** - number=1 정상 조회

### 기본 기능 구현 (90% 완료)
- ✅ **Gemini API 테스트 엔드포인트** - `/api/test-gemini` 구현 완료
- ✅ **홈페이지 구현** - React + Tailwind로 테스트 인터페이스 완성
- ⚠️ **UI 응답 표시 이슈** - API는 정상 작동하나 프론트엔드 응답 지연
- ✅ **Git 커밋 완료** - 74개 파일 변경사항 기록

### UI/UX 개선 및 컴포넌트 구조 최적화 (100% 완료) 🎨 NEW!
- ✅ **컴포넌트 분리 완료** - HexagramInput, HexagramResult, AnalysisTabs, StrategicQuestions
- ✅ **모바일 반응형 디자인** - 768px, 480px 브레이크포인트 대응
- ✅ **접근성(Accessibility) 개선** - aria-label, 키보드 탐색, 포커스 스타일
- ✅ **애니메이션 효과 추가** - fade-in, shimmer 로딩, 부드러운 전환
- ✅ **HTML 프로토타입 완성** - `docs/view_change.html` 완전 기능 구현
- ✅ **React 버전 동기화** - 모든 개선사항 React 컴포넌트에 적용

### 64괘 데이터 완성 (100% 완료) 🎆 **파랍!**
- ✅ **전체 64괘 데이터 입력 완료** - MongoDB seed 액션으로 일괄 입력
- ✅ **기존 데이터 대체** - 5개 테스트 데이터를 완전한 64개로 대체
- ✅ **데이터 무결성 검증** - 전체 64개 괘 정상 조회 확인
- ✅ **기본 구조 완성** - 모든 괘에 6가지 perspectives 기본 설정


### 6가지 관점 생성 시스템 구현 (95% 완료) 📚 **NEW!**
- ✅ **API 엔드포인트 구현** - `/api/ai/generate-perspectives` 완성
- ✅ **6가지 관점 시스템** - 고대철학, 물리학, 생물학, 경영학, 심리학, 군사학
- ✅ **전문 프롬프트 시스템** - 각 학문 분야별 전문성 반영된 프롬프트
- ✅ **AI 응답 파싱 시스템** - 체계적 분석 결과 파싱 및 구조화
- ✅ **단일/전체 관점 생성** - 특정 관점 또는 6가지 모두 생성 기능
- ✅ **에러 처리 및 Rate Limiting** - Gemini API 제한 고려 및 안정성 확보
- ⏳ **API 테스트 및 검증** - 시스템 동작 테스트 진행 중

### 64괘 목록 페이지 (Inline Edit) 구현 및 오류 수정 (100% 완료) ✨ **NEW!**
- ✅ **`src/app/hexagrams/all/page.tsx` 페이지 개발**: 64괘 전체 목록을 테이블 형태로 표시하고, 인라인 편집 기능 구현.
- ✅ **초기 콘솔 오류 해결**: React DevTools 스크립트 관련 오류 및 Next.js `params`/`searchParams` 열거 오류 해결.
  - `src/app/layout.tsx`에 DevTools 스크립트 추가 시도 후, `params` 오류로 인해 해당 스크립트 주석 처리.
- ✅ **인라인 편집으로 리팩토링**: 기존 `HexagramEditModal`을 사용하는 대신, 테이블 내에서 직접 수정할 수 있도록 변경.
  - `editingHexagramId`, `editFormData` 상태 추가 및 관련 핸들러 함수 (`handleStartEdit`, `handleCancelEdit`, `handleFormChange`, `handleSaveEdit`) 구현.
- ✅ **Hydration 오류 해결**: `<tr>` 태그 내부에 잘못된 공백 텍스트 노드가 자식으로 포함되어 발생하던 "In HTML, whitespace text nodes cannot be a child of <tr>" 오류 수정.
  - `page.tsx`의 `hexagrams.map(...)` 부분에서 `<tr>`과 첫 `<td>` 사이의 공백 제거.
### Function Calling MongoDB 연동 시스템 (95% 완성) 🚀 **NEW!**
- ✅ **A-1 세트 MongoDB 연동**: getHexagramInfo, searchHexagramByKeyword 실제 데이터 연동 + 테스트 완료
- ✅ **A-2 세트 고도화**: calculateHexagramCompatibility 정교한 점수 계산 알고리즘
- ✅ **다차원 매칭 시스템**: 감정, 상황, 키워드 기반 지능형 분석
- ✅ **64괘 전체 데이터 활용**: MongoDB에서 실제 괘 데이터 반영
- ✅ **Fallback 처리**: MongoDB 실패시 안정성 보장
- ✅ **A-2 세트 1단계 테스트 성공**: analyze_user_situation 정확한 감정/상황/키워드 추출 확인
- ⏳ **A-2 세트 연속 호출 미완성**: calculate_hexagram_compatibility, select_final_hexagram 단계 연속 호출 안됨

**구현 성과**: 검증된 Function Calling 시스템 완성, 메인 페이지 적용 준비 완료
## 🎯 다음 단계 작업 (진행 중)
**목표**: A-2 세트 연속 호출 문제 해결 또는 대안 제시 후 메인 페이지 적용

1. **테스트 결과 분석 완료**
   - A-1 세트: 완전 성공, 정신 모델 완벽 인용 확인 ✅
   - A-2 세트 1단계: analyze_user_situation 정확한 감정/상황/키워드 추출 성공 ✅
   - A-2 세트 2-3단계: 연속 호출 안됨 ⚠️ (미해결)
   - **주요 성과**: 찰리 멍거 격자틀 이론 기반 과학적 접근법 구현 완료

2. **A-2 세트 연속 호출 문제 해결**
   - Function Declarations 연속 호출 로직 수정
   - calculate_hexagram_compatibility, select_final_hexagram 연결 강화
1. **테스트 페이지에서 Function Calling 기능 검증**
   - A-1 세트: 기본 괘 조회 및 검색 테스트
   - A-2 세트: 고도화된 괘 선택 시스템 테스트

1. **API 동작 테스트**
   - `/api/ai/generate-perspectives` 엔드포인트 정상 동작 확인
   - 단일 관점 생성 테스트 (ancient, physics, biology, business, psychology, military)
   - 전체 6가지 관점 동시 생성 테스트
   - 에러 처리 및 예외 상황 테스트

2. **프론트엔드 연동**
   - 기존 더미 데이터를 실제 AI 생성 데이터로 대체
   - 6가지 관점 탭 시스템과 연동
   - 로딩 상태 및 에러 표시 개선

### Phase 2: 괘 선택 AI 로직 구현 (우선순위 높음) 🤖
**목표**: 사용자 입력 → Gemini 분석 → 적합한 괘 추천 시스템

1. **`/api/ai/select-hexagram` 엔드포인트 구현**
   - 사용자 입력 텍스트 분석
   - Gemini API로 상황 해석 및 감정 추출
   - 64괘 데이터베이스에서 최적 괘 매칭
   - 신뢰도 점수 계산 및 반환

2. **AI 분석 로직 최적화**
   - 프롬프트 엔지니어링으로 정확도 향상
   - 한국어 및 문화적 맥락 반영
   - 에러 처리 및 대안 괘 제안 로직
   - 전략적 질문 및 실행 가능한 조언 제공

2. **관점별 전문성 강화**
   - 각 학문 분야의 전문 용어 및 이론 반영
   - 사용자 상황에 맞는 구체적 예시 제공
   - 실질적이고 실행 가능한 내용 중심

### Phase 3: UI 응답 표시 기능 개선 (중간 우선순위) 🚀
1. **프론트엔드 응답 처리 개선**
   - 현재 Gemini API는 정상 작동하나 프론트엔드 표시 지연 이슈 해결
   - 로딩 상태 및 에러 표시 개선
   - 사용자 경험 최적화

## 🔋 프로젝트 상태 요약

### 완료된 주요 성과 (2025-06-11)
- ✅ **프로젝트 기반 구축**: 100%
- ✅ **MongoDB 데이터베이스 시스템**: 100%
- ✅ **64괘 API 시스템**: 100%
- ✅ **UI/UX 개선 및 컴포넌트 구조**: 100%
- ✅ **64괘 데이터 완성**: 100% 🎆

### 다음 우선순위 작업
1. **괘 선택 AI 로직 구현** - 핵심 기능
2. **6가지 관점 생성 시스템** - 핵심 기능
3. **UI 응답 표시 개선** - 사용자 경험 향상

**현재 전체 진행률**: **80%** (데이터 기반 완성, AI 기능 구현 단계)

---

## 🆕 Google AI 최신 기능 통합 계획 (2025-06-11 NEW!)

### 📋 전략적 접근법
**단계별 구현**: 복잡한 기능을 한번에 구현하지 않고 작은 단위로 나누어 안전하게 테스트
**별도 테스트 페이지**: 메인 페이지 영향 없이 독립적인 검증 환경 구축
**세트별 완료**: 각 기능 세트 완료 및 테스트 후 다음 단계 진행

### 🎯 Phase A: Function Calling 기능 구현
**목표**: Gemini 2.5의 Function Calling을 활용한 고도화된 괘 선택 시스템

#### A-1: 기본 Function Calling 테스트 세트 (진행 예정)
- ✨ **테스트 페이지 생성**: `/src/app/test/gemini-functions/page.tsx`
- ✨ **기본 Function Declaration**: 간단한 괘 정보 조회 함수
- ✨ **Function 구현**: 실제 동작하는 함수 코드 작성
- ✨ **연동 테스트**: Declaration ↔ 구현 ↔ 응답 사이클 검증

#### A-2: 괘 선택 Function Calling 세트 (대기 중)
- ⏳ **사용자 상황 분석 함수**: 입력 텍스트에서 핵심 요소 추출
- ⏳ **괘 적합도 계산 함수**: 64괘 각각의 관련성 점수 계산
- ⏳ **최종 괘 선택 함수**: 논리적 근거와 함께 괘 추천

#### A-3: 6가지 관점 생성 Function Calling 세트 (대기 중)
- ⏳ **Parallel Function Calling**: 6가지 관점 동시 생성
- ⏳ **관점별 전문화 함수**: 각 학문 분야 특화 분석
- ⏳ **결과 통합 시스템**: 6가지 관점을 하나로 조합

### 🌐 Phase B: URL Context 기능 구현
**목표**: 사용자 제공 URL 내용을 분석하여 괘 선택에 반영

#### B-1: 기본 URL Context 테스트 세트 (대기 중)
- ⏳ **URL 읽기 기능**: 단일 URL 내용 분석 테스트
- ⏳ **내용 요약 기능**: URL 내용 핵심 요약
- ⏳ **응답 형식 검증**: `url_context_metadata` 활용

#### B-2: URL + 괘 선택 통합 세트 (대기 중)
- ⏳ **URL 내용 기반 괘 선택**: URL 정보를 괘 선택에 반영
- ⏳ **Google Search 조합**: URL Context + Google Search 동시 활용
- ⏳ **복수 URL 처리**: 최대 20개 URL 동시 분석
### 🔧 기술적 고려사항
- **모델 고정**: `gemini-2.5-flash-preview-05-20` (다른 모델 사용 시 사전 알림 필요)
- **실험적 기능**: URL Context는 실험 단계이므로 변경 가능성 존재
- **쿼터 제한**: URL Context 1500 queries/day, AI Studio 100 queries/day
- **에러 처리**: 각 단계별 상세한 에러 핸들링 구현

### ⚠️ **중요: 최신 Google GenAI API 사용법** (2025-06-11)

**기존 방식(DEPRECATED):**
```typescript
import { GoogleGenerativeAI } from '@google/generative-ai';
const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY!);
const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash-preview-05-20' });
```

**⭐ 새로운 방식(REQUIRED for Function Calling):**
```typescript
import { GoogleGenAI, Type } from '@google/genai'; // 새 패키지!
const ai = new GoogleGenAI({ apiKey: process.env.GOOGLE_API_KEY });
```

**Function Declarations 정의:**
```typescript
const functionDeclaration = {
  name: 'function_name',
  description: 'Function description',
  parameters: {
    type: Type.OBJECT,
    properties: {
      param1: {
        type: Type.STRING, // Type enum 사용 필수!
        description: 'Parameter description'
      },
      param2: {
        type: Type.NUMBER,
        enum: ['option1', 'option2']
      }
    },
    required: ['param1']
  }
};
```

**모델 호출 방식:**
```typescript
const response = await ai.models.generateContent({
  model: 'gemini-2.5-flash-preview-05-20',
  contents: [
    {
      role: 'user',
      parts: [{ text: 'Your prompt here' }]
    }
  ],
  config: {
    tools: [{
      functionDeclarations: [functionDeclaration]
    }]
  }
});
```

**Function Call 응답 처리:**
```typescript
// Function Call 확인
if (response.functionCalls && response.functionCalls.length > 0) {
  const functionCall = response.functionCalls[0];
  console.log(functionCall.name, functionCall.args);
  
  // 함수 실행 후 결과를 다시 모델에 전달
  const functionResult = await executeFunction(functionCall.name, functionCall.args);
  
  contents.push(response.candidates[0].content);
  contents.push({
    role: 'user',
    parts: [{
      functionResponse: {
        name: functionCall.name,
        response: { result: functionResult }
      }
    }]
  });
  
  // 최종 응답 생성
  const finalResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-preview-05-20',
    contents: contents,
    config: config
  });
}
```

**핵심 차이점:**
1. **패키지**: `@google/genai` (새) vs `@google/generative-ai` (구)
2. **클라이언트**: `new GoogleGenAI({})` vs `new GoogleGenerativeAI()`
3. **타입 정의**: `Type.OBJECT`, `Type.STRING` 등 Type enum 필수 사용
4. **호출 방식**: `ai.models.generateContent({})` 구조
5. **응답 처리**: `response.functionCalls[]` 직접 접근
- **에러 처리**: 각 단계별 상세한 에러 핸들링 구현

### 📝 다음 즉시 작업
1. **Gemini Functions 테스트 페이지 생성** - A-1 세트 시작점
2. **기본 Function Calling 구현** - Declaration + 구현 + 테스트
3. **사용자 테스트 및 피드백** - 동작 확인 후 다음 단계 진행

**예상 완성 시기**: 2025년 6월 말 (다음 2주 내)

## ⚠️ 알려진 이슈 및 개선 사항 (2025-06-11)

### Function Calling 테스트 페이지 (`/test/gemini-functions`)
- **Function Results 표시 로직과 JSON 출력 불일치**:
    - `page.tsx`에서는 `funcResultItem.result.success` (boolean) 값을 기준으로 "성공"/"실패" 레이블 및 스타일을 적용합니다.
    - 그러나 실제 API 응답 및 테스트 결과로 제공된 JSON 데이터에는 `funcResultItem.result` 객체 내에 `success` 속성이 포함되어 있지 않습니다.
    - 코드 로직상으로는 "실패"로 표시되어야 하지만, 실제 출력은 "성공"으로 나오고 있어 확인이 필요합니다.
    - **임시 조치**: 현재는 기능 테스트에 집중하고, 이 불일치 문제는 추후 `handleFunctionCall` 함수의 반환 값 구조를 명확히 하거나, `page.tsx`의 결과 표시 로직을 실제 데이터 구조에 맞게 수정하여 해결할 예정입니다.

### 🔧 기술적 고려사항
- **모델 고정**: `gemini-2.5-flash-preview-05-20` (다른 모델 사용 시 사전 알림 필요)
- **실험적 기능**: URL Context는 실험 단계이므로 변경 가능성 존재
- **쿼터 제한**: URL Context 1500 queries/day, AI Studio 100 queries/day
- **에러 처리**: 각 단계별 상세한 에러 핸들링 구현

---

## 🆕 **향후 계획 추가** (2025-06-12)

### 📋 작업 우선순위 재정리

#### **🥇 Phase 1: 8면체 주사위 시스템 완성 (메인 작업)**
**목표**: 팔괘 상징 표시 기술적 이슈 해결 후 MongoDB + Gemini API 통합 완료

**우선순위 1: 팔괘 상징 주사위 면 표시 완성**
- ✅ **현재 상황**: 95% 완료 - 3D 주사위 애니메이션 완성
- ⚠️ **남은 이슈**: Three.js 8면체와 다중 재료 호환성 문제
- 🎯 **해결 방안**: 
  1. **단일 텍스처 UV 매핑**: 하나의 텍스처에 8개 상징을 배치, UV로 분할 (우선 선택)
  2. **3D 텍스트 생성**: TextGeometry로 상징을 3D로 만들어 각 면에 부착
  3. **커스텀 8면체 제작**: 8개 평면을 조합해 각각 다른 텍스처 적용

**우선순위 2: 기존 시스템과 통합**
- 📊 MongoDB 64괘 데이터와 연동
- 🤖 Google Gemini API 해석 엔진 연결  
- 🎲 주사위 결과 → 괘 선택 → AI 해석 전체 플로우 완성

**우선순위 3: 메인 페이지 적용**
- 🔗 `/dice-test` 페이지에서 메인 홈페이지로 연결
- 🎨 UI/UX 최종 조정
- ✅ 사용자 테스트 및 피드백 반영

#### **🥈 Phase 2: Mental Models PDF 통합 시스템 (향후 계획)**
**목표**: 30MB 대용량 PDF `fs-mental-models-en.pdf`를 활용한 동서양 융합 통찰 시스템

**전략적 의미**:
- **64괘 동양 철학** + **서양 Mental Models** = **완전한 사고 툴킷**
- **찰리 멍거 격자틀 이론** 확장: 동양의 지혜 + 서양의 논리적 사고 모델
- **6가지 관점 진화**: 현재 학문 분야별 → 동서양 융합 관점으로 확장

**구현 계획**:
1. **PDF 분석 시스템** (Google Gen AI SDK 활용)
   ```javascript
   import { GoogleGenAI } from "@google/genai";
   const ai = new GoogleGenAI({ apiKey: "GOOGLE_API_KEY" });
   
   // 대용량 PDF 업로드 및 처리
   const file = await ai.files.upload({
     file: 'docs/fs-mental-models-en.pdf',
     config: { displayName: 'Mental Models Encyclopedia' }
   });
   
   // PDF 내용과 64괘 연결 분석
   const response = await ai.models.generateContent({
     model: 'gemini-2.5-flash-preview-05-20',
     contents: [
       'Mental Models와 64괘의 연관성을 분석하고 매핑해주세요',
       createPartFromUri(file.uri, file.mimeType)
     ]
   });
   ```

2. **Mental Models 데이터베이스 구축**
   - 📊 **MongoDB 컬렉션 추가**: `mentalModels` 컬렉션 생성
   - 🔗 **64괘-Mental Models 매핑**: 각 괘와 관련된 사고 모델 연결
   - 📚 **분류 체계**: 인지편향, 의사결정 모델, 시스템 사고 등

3. **통합 관점 시스템 개발**
   - **기존**: 6가지 학문 관점 (고대철학, 물리학, 생물학, 경영학, 심리학, 군사학)
   - **확장**: +3가지 Mental Models 관점
     - **인지과학 관점**: 인지편향, 휴리스틱 분석
     - **의사결정 관점**: 확률적 사고, 베이즈 추론
     - **시스템 사고 관점**: 네트워크 효과, 피드백 루프

4. **AI 분석 엔진 고도화**
   - **Function Calling 확장**: Mental Models 기반 분석 함수 추가
   - **Cross-Reference 시스템**: 동양 괘 ↔ 서양 모델 상호 참조
   - **실무 적용 강화**: 투자, 경영, 전략 결정에 특화

**예상 완성 시기**: Phase 1 완료 후 (2025년 7월 중)

#### **🥉 Phase 3: 고급 기능 및 최적화 (추후 계획)**
- 🎨 **3D 주사위 고도화**: 물리 엔진, 사운드 효과, 파티클 효과
- 📱 **모바일 최적화**: 터치 인터랙션, 반응형 3D 렌더링
- 📊 **사용자 데이터 분석**: 괘 패턴 분석, 개인화 추천
- 🌐 **소셜 기능**: 결과 공유, 커뮤니티 기능

### 🎯 **즉시 다음 작업 (Option A 실행)**
1. **팔괘 상징 표시 기술적 이슈 해결** (우선순위 1)
   - 단일 텍스처 UV 매핑 방식으로 구현
   - `/dice-test` 페이지에서 실제 팔괘 상징 표시 완성

2. **MongoDB + Gemini API 통합 테스트**
   - 주사위 결과 → 괘 번호 계산 → 데이터베이스 조회
   - Gemini API로 상황별 해석 생성

3. **메인 페이지 적용 준비**
   - 전체 플로우 테스트 및 버그 수정
   - 사용자 경험 최적화

**작업 진행 동의를 구합니다. Option A (8면체 주사위 시스템 완성)부터 시작하겠습니다.**
